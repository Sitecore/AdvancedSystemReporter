Installs Advanced System Reporter components. No further steps are required.

If you want to use the Email functionality make sure the default mail settings in the web.config are set correctly to access a mail server.